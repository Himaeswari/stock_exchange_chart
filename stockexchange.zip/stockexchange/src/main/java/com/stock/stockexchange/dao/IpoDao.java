package com.stock.stockexchange.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.stock.stockexchange.model.IpoPlanned;

public interface IpoDao extends JpaRepository<IpoPlanned,Integer> {

	@Query("Select c From IpoPlanned c  where c.companyName= :cname ")
	List<IpoPlanned> findByIpoByCompanyName(@Param("cname") String cname);
}
