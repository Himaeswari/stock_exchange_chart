package com.stock.stockexchange.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stock.stockexchange.dao.IpoDao;
import com.stock.stockexchange.model.IpoPlanned;

@RequestMapping("/api")
@RestController
public class IpoController {
	
	@Autowired
	IpoDao ipoDao;
	@GetMapping("/getIpoByCompany/{cname}")
	public List<IpoPlanned> getAllCustomers(@PathVariable("cname") String cname) {
		System.out.println("Get all company by sector...");

		List<IpoPlanned> ipo = new ArrayList<>();
		ipo=ipoDao.findByIpoByCompanyName(cname);

		return ipo;
	}


}
