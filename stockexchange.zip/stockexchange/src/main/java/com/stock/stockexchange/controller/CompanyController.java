package com.stock.stockexchange.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.stock.stockexchange.dao.SectorDao;
import com.stock.stockexchange.model.Sector;
import com.stock.stockexchange.service.SectorService;


@RequestMapping("/api")
@RestController
public class CompanyController {
	
	@Autowired
	SectorService sectorService;
	@GetMapping("/companybysector/{id}")
	public List<Sector> getAllCustomers(@PathVariable("id") int id) {
		System.out.println("Get all company by sector...");

		List<Sector> company = new ArrayList<>();
		company=sectorService.findCompanyBySector(id);

		return company;
	}

}
