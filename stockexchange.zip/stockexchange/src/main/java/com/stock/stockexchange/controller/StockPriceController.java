package com.stock.stockexchange.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stock.stockexchange.dao.StockPriceDao;
import com.stock.stockexchange.model.Sector;
import com.stock.stockexchange.service.SectorService;

@RequestMapping("/api")
@RestController
public class StockPriceController {

	
	@Autowired
    StockPriceDao stockPriceDao;
	@GetMapping("/stockPrice/{id}")
	public float getAllCustomers(@PathVariable("id") int id) {
		System.out.println("Get all company by sector...");

		
		float stockPrice=stockPriceDao.findStockPrice(id);

		return stockPrice;
	}
}
